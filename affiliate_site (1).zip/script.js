document.addEventListener("DOMContentLoaded", function () {
    const banner = document.getElementById("cookieBanner");
    const acceptBtn = document.getElementById("acceptCookies");

    banner.style.display = "flex";

    acceptBtn.addEventListener("click", function () {
        document.cookie = "affiliate_accepted=yes;path=/;max-age=31536000";
        window.location.href = "https://app.monetizze.com.br/r/AXQ25406591";
    });
});
